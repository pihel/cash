Домашняя бухгалтерия на ExtJS 4, PHP 5, SQLite 3.
Демо - cash.pihel.jino.ru
chown -R www-data ./

git add *
git commit -a -m ''
git push -u origin master