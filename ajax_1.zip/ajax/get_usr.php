<?
require_once("../lib/init.php");
echo intval( $usr->id );