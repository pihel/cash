<?
$sqlite_path = __DIR__."/../data/cash.sqlite";
$site_name = 'Домашняя бухгалтерия';
?>