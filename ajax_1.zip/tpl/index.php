<!doctype html>
<html>
  <head>
    <meta charset=utf-8>
    <title><?=$t[1];?></title>
    <link href="static/style.css" media="all" rel="stylesheet" type="text/css" />
    <link href="static/ext/resources/css/ext-all.css" media="all" rel="stylesheet" type="text/css" />
    <link href="static/ext/ux/grid/css/GridFilters.css" rel="stylesheet" type="text/css" />
    <link href="static/ext/ux/grid/css/RangeMenu.css" rel="stylesheet" type="text/css" />
    <script src="static/ext/ext-all.js" 	type="text/javascript"></script>
    <script src="static/ext/ext-lang-ru.js" 	type="text/javascript"></script>
    <script src="static/user/script.js" 	type="text/javascript"></script>


    <link rel="shortcut icon" href="static/favicon.png" />
  </head>
  <body id="main">
    &nbsp;
  </body>
</html>