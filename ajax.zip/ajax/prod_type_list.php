<?
require_once("../lib/init.php");
echo json_encode( $ch->prod_type_list() );
?>
